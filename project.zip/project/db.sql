CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT
);

INSERT OR IGNORE INTO settings (key, value) VALUES ('site_name', 'موقعي');
INSERT OR IGNORE INTO settings (key, value) VALUES ('site_logo', '');
INSERT OR IGNORE INTO settings (key, value) VALUES ('developer_signature', 'تطوير: فريق التطوير');
INSERT OR IGNORE INTO settings (key, value) VALUES ('keywords', 'موقع, تطبيقات, برمجة');

CREATE TABLE IF NOT EXISTS pages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  type TEXT NOT NULL CHECK(type IN ('home','about','contact','app')),
  content TEXT,
  app_type TEXT,
  app_file TEXT,
  sort_order INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cliches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  page_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  image TEXT,
  sort_order INTEGER DEFAULT 0,
  FOREIGN KEY (page_id) REFERENCES pages(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS bot_states (
  chat_id INTEGER PRIMARY KEY,
  state TEXT NOT NULL DEFAULT 'idle',
  data TEXT
);
