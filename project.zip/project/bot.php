<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/debug.log');

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/keyboards.php';

set_exception_handler(function ($e) {
    error_log('Uncaught exception: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
});

try {

$update = json_decode(file_get_contents('php://input'), true);
if (!$update) {
    exit;
}

// ---------- استخراج بيانات الرسالة أو الضغطة ----------
$message = $update['message'] ?? null;
$callback = $update['callback_query'] ?? null;

$chatId = $message['chat']['id'] ?? ($callback['message']['chat']['id'] ?? null);
$fromId = $message['from']['id'] ?? ($callback['from']['id'] ?? null);

if (!$chatId || !$fromId) {
    exit;
}

// ---------- التحقق أن المرسل هو المشرف فقط ----------
if ((string)$fromId !== (string)ADMIN_ID) {
    if ($message) {
        sendMessage($chatId, 'غير مصرح لك باستخدام هذا البوت.');
    }
    exit;
}

// ================================================================
//                       التعامل مع الأزرار (Callback)
// ================================================================
if ($callback) {
    $data = $callback['data'];
    $messageId = $callback['message']['message_id'];
    answerCallback($callback['id']);

    if ($data === 'main_menu') {
        clearState($chatId);
        reply($chatId, $messageId, 'القائمة الرئيسية:', kb_main());

    } elseif ($data === 'pages_menu') {
        clearState($chatId);
        reply($chatId, $messageId, 'إدارة الصفحات:', kb_pages_menu());

    } elseif ($data === 'list_pages') {
        $pages = getAllPages();
        if (!$pages) {
            reply($chatId, $messageId, 'لا توجد صفحات حالياً. أضف صفحة أولاً.', kb_pages_menu());
        } else {
            reply($chatId, $messageId, 'اختر صفحة لعرض تفاصيلها أو تعديلها:', kb_pages_list_for_view($pages));
        }

    } elseif (strpos($data, 'view_page:') === 0) {
        $id = (int)substr($data, strlen('view_page:'));
        $page = getPageById($id);
        if (!$page) {
            reply($chatId, $messageId, 'هذه الصفحة لم تعد موجودة.', kb_pages_menu());
        } else {
            $info = "العنوان: {$page['title']}\n";
            $info .= "النوع: " . typeLabel($page['type']) . "\n";
            if ($page['type'] === 'app') {
                $info .= "نوع التطبيق: " . ($page['app_type'] ?? '-') . "\n";
                $info .= "الملف المرفوع: " . ($page['app_file'] ? 'موجود' : 'غير موجود') . "\n";
            }
            $info .= "\nالمحتوى:\n" . ($page['content'] ?: '(بدون محتوى)');
            reply($chatId, $messageId, $info, kb_page_detail($id));
        }

    } elseif (strpos($data, 'edit_page_title:') === 0) {
        $id = (int)substr($data, strlen('edit_page_title:'));
        setState($chatId, 'edit_page_title', ['id' => $id]);
        reply($chatId, $messageId, 'أرسل العنوان الجديد لهذه الصفحة:', kb_cancel_only());

    } elseif (strpos($data, 'edit_page_content:') === 0) {
        $id = (int)substr($data, strlen('edit_page_content:'));
        setState($chatId, 'edit_page_content', ['id' => $id]);
        reply($chatId, $messageId, "أرسل المحتوى الجديد لهذه الصفحة:\n\nنصيحة: اترك سطر فاضي بين كل فقرة وأخرى، ولإضافة زر حقيقي اكتب:\n[نص الزر](https://رابط)", kb_cancel_only());

    } elseif ($data === 'add_page') {
        reply($chatId, $messageId, 'اختر نوع الصفحة:', kb_page_types());

    } elseif (strpos($data, 'add_page_type:') === 0) {
        $type = substr($data, strlen('add_page_type:'));
        setState($chatId, 'add_page_title', ['type' => $type]);
        reply($chatId, $messageId, 'أرسل الآن اسم الصفحة (نص):', kb_cancel_only());

    } elseif ($data === 'del_pages_menu') {
        $pages = getAllPages();
        if (!$pages) {
            reply($chatId, $messageId, 'لا توجد صفحات لحذفها.', kb_pages_menu());
        } else {
            reply($chatId, $messageId, 'اختر الصفحة المراد حذفها:', kb_pages_list_for_delete($pages));
        }

    } elseif (strpos($data, 'del_page_confirm:') === 0) {
        $id = (int)substr($data, strlen('del_page_confirm:'));
        $page = getPageById($id);
        if ($page) {
            if (!empty($page['app_file']) && file_exists(UPLOAD_APPS_DIR . $page['app_file'])) {
                @unlink(UPLOAD_APPS_DIR . $page['app_file']);
            }
            $stmt = db()->prepare("DELETE FROM pages WHERE id = ?");
            $stmt->execute([$id]);
        }
        reply($chatId, $messageId, 'تم حذف الصفحة.', kb_pages_menu());

    } elseif (strpos($data, 'del_page:') === 0) {
        $id = (int)substr($data, strlen('del_page:'));
        $page = getPageById($id);
        if ($page) {
            reply($chatId, $messageId, "هل أنت متأكد من حذف الصفحة: {$page['title']}؟", kb_confirm_delete_page($id));
        }

    } elseif ($data === 'cliches_menu') {
        clearState($chatId);
        reply($chatId, $messageId, 'إدارة الكليشات:', kb_cliches_menu());

    } elseif ($data === 'add_cliche') {
        $pages = getAllPages();
        if (!$pages) {
            reply($chatId, $messageId, 'لا توجد صفحات بعد، أضف صفحة أولاً.', kb_cliches_menu());
        } else {
            reply($chatId, $messageId, 'اختر الصفحة لإضافة الكليشة إليها:', kb_pages_list_for_cliche_add($pages));
        }

    } elseif (strpos($data, 'cliche_page_select:') === 0) {
        $pageId = (int)substr($data, strlen('cliche_page_select:'));
        setState($chatId, 'add_cliche_title', ['page_id' => $pageId]);
        reply($chatId, $messageId, 'أرسل عنوان الكليشة:', kb_cancel_only());

    } elseif ($data === 'cliche_skip_image') {
        $state = getState($chatId);
        $d = $state['data'];
        if (isset($d['page_id'], $d['title'], $d['description'])) {
            saveCliche((int)$d['page_id'], $d['title'], $d['description'], null);
            clearState($chatId);
            reply($chatId, $messageId, 'تمت إضافة الكليشة بنجاح.', kb_cliches_menu());
        } else {
            reply($chatId, $messageId, 'انتهت صلاحية هذه الخطوة، ابدأ من جديد.', kb_cliches_menu());
        }

    } elseif ($data === 'cliches_pages_menu') {
        $pages = getAllPages();
        if (!$pages) {
            reply($chatId, $messageId, 'لا توجد صفحات.', kb_cliches_menu());
        } else {
            reply($chatId, $messageId, 'اختر الصفحة لعرض كليشاتها:', kb_pages_list_for_cliche_browse($pages));
        }

    } elseif (strpos($data, 'cliche_browse_page:') === 0) {
        $pageId = (int)substr($data, strlen('cliche_browse_page:'));
        setState($chatId, 'idle', ['browsing_page_id' => $pageId]);
        $cliches = getClichesByPage($pageId);
        if (!$cliches) {
            reply($chatId, $messageId, 'لا توجد كليشات لهذه الصفحة.', kb_cliches_menu());
        } else {
            reply($chatId, $messageId, 'اختر كليشة لعرضها أو تعديلها:', kb_cliches_list($cliches));
        }

    } elseif (strpos($data, 'view_cliche:') === 0) {
        $id = (int)substr($data, strlen('view_cliche:'));
        $c = getClicheById($id);
        if (!$c) {
            reply($chatId, $messageId, 'هذه الكليشة لم تعد موجودة.', kb_cliches_menu());
        } else {
            $info = "العنوان: {$c['title']}\n\nالوصف:\n" . ($c['description'] ?: '(بدون وصف)');
            reply($chatId, $messageId, $info, kb_cliche_detail($id));
        }

    } elseif (strpos($data, 'edit_cliche_title:') === 0) {
        $id = (int)substr($data, strlen('edit_cliche_title:'));
        setState($chatId, 'edit_cliche_title', ['id' => $id]);
        reply($chatId, $messageId, 'أرسل العنوان الجديد لهذه الكليشة:', kb_cancel_only());

    } elseif (strpos($data, 'edit_cliche_desc:') === 0) {
        $id = (int)substr($data, strlen('edit_cliche_desc:'));
        setState($chatId, 'edit_cliche_desc', ['id' => $id]);
        reply($chatId, $messageId, 'أرسل الوصف الجديد لهذه الكليشة:', kb_cancel_only());

    } elseif (strpos($data, 'del_cliche_confirm:') === 0) {
        $id = (int)substr($data, strlen('del_cliche_confirm:'));
        $c = getClicheById($id);
        if ($c && !empty($c['image']) && file_exists(UPLOAD_SITE_DIR . $c['image'])) {
            @unlink(UPLOAD_SITE_DIR . $c['image']);
        }
        $stmt = db()->prepare("DELETE FROM cliches WHERE id = ?");
        $stmt->execute([$id]);
        reply($chatId, $messageId, 'تم حذف الكليشة.', kb_cliches_menu());

    } elseif (strpos($data, 'del_cliche:') === 0) {
        $id = (int)substr($data, strlen('del_cliche:'));
        reply($chatId, $messageId, 'تأكيد حذف هذه الكليشة؟', kb_confirm_delete_cliche($id));

    } elseif ($data === 'site_settings_menu') {
        clearState($chatId);
        reply($chatId, $messageId, 'إعدادات الموقع:', kb_site_settings_menu());

    } elseif ($data === 'edit_sitename') {
        setState($chatId, 'edit_sitename');
        reply($chatId, $messageId, 'اسم الموقع الحالي: ' . getSetting('site_name') . "\n\nأرسل اسم الموقع الجديد:", kb_cancel_only());

    } elseif ($data === 'edit_logo') {
        setState($chatId, 'edit_logo');
        reply($chatId, $messageId, 'أرسل صورة الشعار الجديدة:', kb_cancel_only());

    } elseif ($data === 'edit_keywords') {
        setState($chatId, 'edit_keywords');
        reply($chatId, $messageId, 'الكلمات الحالية: ' . getSetting('keywords') . "\n\nأرسل الكلمات المفتاحية الجديدة مفصولة بفواصل:", kb_cancel_only());

    } elseif ($data === 'edit_signature') {
        setState($chatId, 'edit_signature');
        reply($chatId, $messageId, 'التوقيع الحالي: ' . getSetting('developer_signature') . "\n\nأرسل نص توقيع المطور الجديد:", kb_cancel_only());
    }
    exit;
}

// ================================================================
//                       التعامل مع الرسائل (نص / صورة / ملف)
// ================================================================
if ($message) {
    $text = trim($message['text'] ?? '');

    if ($text === '/start') {
        clearState($chatId);
        sendMessage($chatId, 'أهلاً بك في لوحة تحكم الموقع.', kb_main());
        exit;
    }

    if ($text === '/help') {
        sendMessage($chatId, "هذا البوت يدير موقعك بالكامل. استخدم /start لعرض القائمة الرئيسية في أي وقت.");
        exit;
    }

    $state = getState($chatId);
    $current = $state['state'];
    $data = $state['data'];

    switch ($current) {
        case 'add_page_title':
            if ($text === '') { sendMessage($chatId, 'الرجاء إرسال نص صالح.'); exit; }
            $data['title'] = $text;
            if (($data['type'] ?? '') === 'app') {
                setState($chatId, 'add_page_app_type', $data);
                sendMessage($chatId, 'أرسل نوع التطبيق (مثال: أندرويد، iOS):');
            } else {
                setState($chatId, 'add_page_content', $data);
                sendMessage($chatId, "أرسل محتوى/نص الصفحة:\n\nنصيحة: اترك سطر فاضي بين كل فقرة وأخرى (بدل عدة أسطر فارغة متتالية)، ولإضافة زر حقيقي اكتب:\n[نص الزر](https://رابط)");
            }
            break;

        case 'add_page_content':
            if ($text === '') { sendMessage($chatId, 'الرجاء إرسال نص صالح.'); exit; }
            $slug = slugify($data['title']);
            $stmt = db()->prepare("INSERT INTO pages (title, slug, type, content) VALUES (?, ?, ?, ?)");
            $stmt->execute([$data['title'], $slug, $data['type'], $text]);
            clearState($chatId);
            sendMessage($chatId, 'تمت إضافة الصفحة بنجاح.', kb_pages_menu());
            break;

        case 'add_page_app_type':
            if ($text === '') { sendMessage($chatId, 'الرجاء إرسال نص صالح.'); exit; }
            $data['app_type'] = $text;
            setState($chatId, 'add_page_app_desc', $data);
            sendMessage($chatId, "أرسل وصف/محتوى صفحة التطبيق:\n\nنصيحة: اترك سطر فاضي بين كل فقرة وأخرى، ولإضافة زر حقيقي اكتب:\n[نص الزر](https://رابط)");
            break;

        case 'add_page_app_desc':
            if ($text === '') { sendMessage($chatId, 'الرجاء إرسال نص صالح.'); exit; }
            $data['content'] = $text;
            setState($chatId, 'add_page_app_file', $data);
            sendMessage($chatId, "الآن أرسل ملف التطبيق كـ Document.\n\nملاحظة: تيليغرام يمنع البوتات من تحميل ملفات أكبر من 20 ميجابايت. إذا كان حجم ملفك أكبر من ذلك، ارفعه لأي مكان (مثل تخزين موقعك أو Google Drive برابط تحميل مباشر) وأرسل لي رابط التحميل المباشر كنص بدلاً من الملف.");
            break;

        case 'add_page_app_file':
            $doc = $message['document'] ?? null;

            if ($doc) {
                $slug = slugify($data['title']);
                $savedName = downloadTelegramFile($doc['file_id'], UPLOAD_APPS_DIR, $slug);
                if (!$savedName) {
                    sendMessage($chatId, "فشل تحميل الملف عبر تيليغرام (غالباً لأن حجمه أكبر من 20 ميجابايت، وهذا قيد من تيليغرام نفسه على كل البوتات).\n\nأرسل بدلاً منه رابط تحميل مباشر للملف كنص.");
                    exit;
                }
            } elseif ($text !== '' && preg_match('/^https?:\/\//i', $text)) {
                $slug = slugify($data['title']);
                $savedName = downloadFromUrl($text, UPLOAD_APPS_DIR, $slug);
                if (!$savedName) {
                    sendMessage($chatId, 'فشل تحميل الملف من الرابط. تأكد أن الرابط مباشر لملف (وليس صفحة تحميل) وحاول مرة أخرى.');
                    exit;
                }
            } else {
                sendMessage($chatId, 'أرسل الملف كـ Document، أو رابط تحميل مباشر يبدأ بـ http أو https.');
                exit;
            }

            $stmt = db()->prepare("INSERT INTO pages (title, slug, type, content, app_type, app_file) VALUES (?, ?, 'app', ?, ?, ?)");
            $stmt->execute([$data['title'], $slug, $data['content'], $data['app_type'], $savedName]);
            clearState($chatId);
            sendMessage($chatId, 'تمت إضافة صفحة التطبيق ورفع الملف بنجاح.', kb_pages_menu());
            break;

        case 'edit_page_title':
            if ($text === '' || empty($data['id'])) { sendMessage($chatId, 'الرجاء إرسال نص صالح.'); exit; }
            updatePageTitle((int)$data['id'], $text);
            clearState($chatId);
            sendMessage($chatId, 'تم تحديث عنوان الصفحة.', kb_pages_menu());
            break;

        case 'edit_page_content':
            if ($text === '' || empty($data['id'])) { sendMessage($chatId, 'الرجاء إرسال نص صالح.'); exit; }
            updatePageContent((int)$data['id'], $text);
            clearState($chatId);
            sendMessage($chatId, 'تم تحديث محتوى الصفحة.', kb_pages_menu());
            break;

        case 'add_cliche_title':
            if ($text === '') { sendMessage($chatId, 'الرجاء إرسال نص صالح.'); exit; }
            $data['title'] = $text;
            setState($chatId, 'add_cliche_desc', $data);
            sendMessage($chatId, 'أرسل وصف الكليشة:');
            break;

        case 'add_cliche_desc':
            if ($text === '') { sendMessage($chatId, 'الرجاء إرسال نص صالح.'); exit; }
            $data['description'] = $text;
            setState($chatId, 'add_cliche_image', $data);
            sendMessage($chatId, 'أرسل صورة الكليشة، أو اضغط تخطي:', kb_skip_image());
            break;

        case 'add_cliche_image':
            $photo = $message['photo'] ?? null;
            if (!$photo) {
                sendMessage($chatId, 'الرجاء إرسال صورة، أو اضغط زر التخطي.', kb_skip_image());
                exit;
            }
            $fileId = end($photo)['file_id'];
            $imgName = downloadTelegramFile($fileId, UPLOAD_SITE_DIR, 'cliche-' . uniqid());
            saveCliche((int)$data['page_id'], $data['title'], $data['description'], $imgName);
            clearState($chatId);
            sendMessage($chatId, 'تمت إضافة الكليشة بنجاح.', kb_cliches_menu());
            break;

        case 'edit_cliche_title':
            if ($text === '' || empty($data['id'])) { sendMessage($chatId, 'الرجاء إرسال نص صالح.'); exit; }
            $stmt = db()->prepare("UPDATE cliches SET title = ? WHERE id = ?");
            $stmt->execute([$text, (int)$data['id']]);
            clearState($chatId);
            sendMessage($chatId, 'تم تحديث عنوان الكليشة.', kb_cliches_menu());
            break;

        case 'edit_cliche_desc':
            if ($text === '' || empty($data['id'])) { sendMessage($chatId, 'الرجاء إرسال نص صالح.'); exit; }
            $stmt = db()->prepare("UPDATE cliches SET description = ? WHERE id = ?");
            $stmt->execute([$text, (int)$data['id']]);
            clearState($chatId);
            sendMessage($chatId, 'تم تحديث وصف الكليشة.', kb_cliches_menu());
            break;

        case 'edit_sitename':
            if ($text === '') { sendMessage($chatId, 'الرجاء إرسال نص صالح.'); exit; }
            setSetting('site_name', $text);
            clearState($chatId);
            sendMessage($chatId, 'تم تحديث اسم الموقع.', kb_site_settings_menu());
            break;

        case 'edit_logo':
            $photo = $message['photo'] ?? null;
            if (!$photo) {
                sendMessage($chatId, 'الرجاء إرسال صورة صالحة.');
                exit;
            }
            $fileId = end($photo)['file_id'];
            $imgName = downloadTelegramFile($fileId, UPLOAD_SITE_DIR, 'logo');
            if ($imgName) {
                setSetting('site_logo', $imgName);
                clearState($chatId);
                sendMessage($chatId, 'تم تحديث شعار الموقع.', kb_site_settings_menu());
            } else {
                sendMessage($chatId, 'فشل رفع الصورة، تأكد من صلاحيات الكتابة وحاول مرة أخرى.');
            }
            break;

        case 'edit_keywords':
            if ($text === '') { sendMessage($chatId, 'الرجاء إرسال نص صالح.'); exit; }
            setSetting('keywords', $text);
            clearState($chatId);
            sendMessage($chatId, 'تم تحديث الكلمات المفتاحية.', kb_site_settings_menu());
            break;

        case 'edit_signature':
            if ($text === '') { sendMessage($chatId, 'الرجاء إرسال نص صالح.'); exit; }
            setSetting('developer_signature', $text);
            clearState($chatId);
            sendMessage($chatId, 'تم تحديث توقيع المطور.', kb_site_settings_menu());
            break;

        default:
            sendMessage($chatId, 'اختر من القائمة:', kb_main());
    }
}

} catch (\Throwable $e) {
    error_log('Bot fatal error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
}

// ================================================================
//                          دوال مساعدة محلية
// ================================================================
function typeLabel(string $type): string
{
    switch ($type) {
        case 'home': return 'رئيسية';
        case 'about': return 'نبذة عنا';
        case 'contact': return 'اتصل بنا';
        case 'app': return 'تحميل تطبيق';
        default: return $type;
    }
}

function saveCliche(int $pageId, string $title, string $desc, ?string $image): void
{
    $stmt = db()->prepare("INSERT INTO cliches (page_id, title, description, image) VALUES (?, ?, ?, ?)");
    $stmt->execute([$pageId, $title, $desc, $image]);
}
