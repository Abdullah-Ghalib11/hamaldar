<?php
// ================== إعدادات قاعدة البيانات (SQLite) ==================
// لا تحتاج أي بيانات دخول، فقط تأكد أن هذا المسار قابل للكتابة من السيرفر
define('DB_PATH', __DIR__ . '/database.sqlite');

// ================== إعدادات البوت ==================
define('BOT_TOKEN', '8036614638:AAEFFa0pP9D2xT-JD1uXc1TYcbgzYxmCNX4');
define('ADMIN_ID', 7387992296); // آيدي التيليغرام المسموح له بالتحكم بالبوت فقط

// ================== إعدادات الموقع ==================
define('SITE_URL', 'https://hamaldar.online'); // الرابط الظاهر للزوار (جذر الدومين)
define('PROJECT_URL', 'https://hamaldar.online/project'); // المكان الفعلي لملفات المشروع (لا تغيّره إلا لو نقلت الملفات)
define('UPLOAD_APPS_DIR', __DIR__ . '/uploads/apps/');
define('UPLOAD_SITE_DIR', __DIR__ . '/uploads/site/');
define('UPLOAD_APPS_URL', PROJECT_URL . '/uploads/apps/');
define('UPLOAD_SITE_URL', PROJECT_URL . '/uploads/site/');
define('ASSETS_URL', PROJECT_URL . '/assets/');

// الألوان ثابتة في الموقع بالكامل (برتقالي + أبيض) - لا تُعدَّل من البوت
define('COLOR_PRIMARY', '#FF7A1A');
define('COLOR_PRIMARY_DARK', '#E0630B');
define('COLOR_WHITE', '#FFFFFF');

// ================== الاتصال بقاعدة البيانات ==================
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $isNew = !file_exists(DB_PATH);
        $pdo = new PDO('sqlite:' . DB_PATH);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec('PRAGMA foreign_keys = ON;');
        if ($isNew) {
            initDatabase($pdo);
        }
    }
    return $pdo;
}

// إنشاء الجداول تلقائياً عند أول استخدام (لا حاجة لاستيراد ملف SQL يدوياً)
function initDatabase(PDO $pdo): void
{
    $schema = file_get_contents(__DIR__ . '/db.sql');
    $pdo->exec($schema);
}
