<?php

function kb_main(): array
{
    return [
        [['text' => 'إدارة الصفحات', 'callback_data' => 'pages_menu']],
        [['text' => 'إدارة الكليشات', 'callback_data' => 'cliches_menu']],
        [['text' => 'إعدادات الموقع', 'callback_data' => 'site_settings_menu']],
    ];
}

function kb_pages_menu(): array
{
    return [
        [['text' => 'إضافة صفحة', 'callback_data' => 'add_page']],
        [['text' => 'عرض / تعديل الصفحات', 'callback_data' => 'list_pages']],
        [['text' => 'حذف صفحة', 'callback_data' => 'del_pages_menu']],
        [['text' => 'رجوع للقائمة الرئيسية', 'callback_data' => 'main_menu']],
    ];
}

function kb_page_types(): array
{
    return [
        [['text' => 'الصفحة الرئيسية', 'callback_data' => 'add_page_type:home']],
        [['text' => 'نبذة عنا', 'callback_data' => 'add_page_type:about']],
        [['text' => 'اتصل بنا', 'callback_data' => 'add_page_type:contact']],
        [['text' => 'صفحة تحميل تطبيق', 'callback_data' => 'add_page_type:app']],
        [['text' => 'إلغاء', 'callback_data' => 'pages_menu']],
    ];
}

function kb_pages_list_for_view(array $pages): array
{
    $rows = [];
    foreach ($pages as $p) {
        $rows[] = [['text' => $p['title'], 'callback_data' => 'view_page:' . $p['id']]];
    }
    $rows[] = [['text' => 'رجوع', 'callback_data' => 'pages_menu']];
    return $rows;
}

function kb_page_detail(int $id): array
{
    return [
        [['text' => 'تعديل العنوان', 'callback_data' => 'edit_page_title:' . $id]],
        [['text' => 'تعديل المحتوى', 'callback_data' => 'edit_page_content:' . $id]],
        [['text' => 'حذف هذه الصفحة', 'callback_data' => 'del_page:' . $id]],
        [['text' => 'رجوع لقائمة الصفحات', 'callback_data' => 'list_pages']],
    ];
}

function kb_pages_list_for_delete(array $pages): array
{
    $rows = [];
    foreach ($pages as $p) {
        $rows[] = [['text' => $p['title'], 'callback_data' => 'del_page:' . $p['id']]];
    }
    $rows[] = [['text' => 'رجوع', 'callback_data' => 'pages_menu']];
    return $rows;
}

function kb_confirm_delete_page(int $id): array
{
    return [
        [
            ['text' => 'تأكيد الحذف', 'callback_data' => 'del_page_confirm:' . $id],
            ['text' => 'إلغاء', 'callback_data' => 'view_page:' . $id],
        ],
    ];
}

function kb_cliches_menu(): array
{
    return [
        [['text' => 'إضافة كليشة لصفحة', 'callback_data' => 'add_cliche']],
        [['text' => 'عرض / تعديل / حذف كليشة', 'callback_data' => 'cliches_pages_menu']],
        [['text' => 'رجوع للقائمة الرئيسية', 'callback_data' => 'main_menu']],
    ];
}

function kb_pages_list_for_cliche_add(array $pages): array
{
    $rows = [];
    foreach ($pages as $p) {
        $rows[] = [['text' => $p['title'], 'callback_data' => 'cliche_page_select:' . $p['id']]];
    }
    $rows[] = [['text' => 'رجوع', 'callback_data' => 'cliches_menu']];
    return $rows;
}

function kb_pages_list_for_cliche_browse(array $pages): array
{
    $rows = [];
    foreach ($pages as $p) {
        $rows[] = [['text' => $p['title'], 'callback_data' => 'cliche_browse_page:' . $p['id']]];
    }
    $rows[] = [['text' => 'رجوع', 'callback_data' => 'cliches_menu']];
    return $rows;
}

function kb_cliches_list(array $cliches): array
{
    $rows = [];
    foreach ($cliches as $c) {
        $rows[] = [['text' => $c['title'], 'callback_data' => 'view_cliche:' . $c['id']]];
    }
    $rows[] = [['text' => 'رجوع', 'callback_data' => 'cliches_pages_menu']];
    return $rows;
}

function kb_cliche_detail(int $id): array
{
    return [
        [['text' => 'تعديل العنوان', 'callback_data' => 'edit_cliche_title:' . $id]],
        [['text' => 'تعديل الوصف', 'callback_data' => 'edit_cliche_desc:' . $id]],
        [['text' => 'حذف هذه الكليشة', 'callback_data' => 'del_cliche:' . $id]],
        [['text' => 'رجوع', 'callback_data' => 'cliches_pages_menu']],
    ];
}

function kb_confirm_delete_cliche(int $id): array
{
    return [
        [
            ['text' => 'تأكيد الحذف', 'callback_data' => 'del_cliche_confirm:' . $id],
            ['text' => 'إلغاء', 'callback_data' => 'view_cliche:' . $id],
        ],
    ];
}

function kb_skip_image(): array
{
    return [
        [['text' => 'بدون صورة (تخطي)', 'callback_data' => 'cliche_skip_image']],
        [['text' => 'إلغاء', 'callback_data' => 'cliches_menu']],
    ];
}

function kb_site_settings_menu(): array
{
    return [
        [['text' => 'تغيير اسم الموقع', 'callback_data' => 'edit_sitename']],
        [['text' => 'تغيير صورة/شعار الموقع', 'callback_data' => 'edit_logo']],
        [['text' => 'تغيير الكلمات المفتاحية (SEO)', 'callback_data' => 'edit_keywords']],
        [['text' => 'تغيير توقيع المطور', 'callback_data' => 'edit_signature']],
        [['text' => 'رجوع للقائمة الرئيسية', 'callback_data' => 'main_menu']],
    ];
}

function kb_cancel_only(): array
{
    return [[['text' => 'إلغاء', 'callback_data' => 'main_menu']]];
}
