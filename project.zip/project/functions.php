<?php
require_once __DIR__ . '/config.php';

// ============================================================
//                     دوال تيليغرام العامة
// ============================================================

// كل استدعاء لتيليغرام يسجل نفسه تلقائياً في debug.log عند حدوث أي خطأ
function tg_api(string $method, array $params = [])
{
    $url = 'https://api.telegram.org/bot' . BOT_TOKEN . '/' . $method;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    $result = curl_exec($ch);
    $curlErrNo = curl_errno($ch);
    $curlErr = curl_error($ch);
    curl_close($ch);

    if ($curlErrNo) {
        error_log("[tg_api:$method] CURL error #$curlErrNo: $curlErr");
        return ['ok' => false, 'curl_error' => $curlErr];
    }

    $decoded = json_decode($result, true);
    if (!is_array($decoded) || empty($decoded['ok'])) {
        error_log("[tg_api:$method] Telegram error: " . ($result !== false ? $result : 'empty response'));
    }
    return $decoded ?: ['ok' => false];
}

function sendMessage($chatId, string $text, array $keyboard = null)
{
    $params = [
        'chat_id' => $chatId,
        'text' => $text,
        'parse_mode' => 'HTML',
    ];
    if ($keyboard !== null) {
        $params['reply_markup'] = json_encode(['inline_keyboard' => $keyboard], JSON_UNESCAPED_UNICODE);
    }
    return tg_api('sendMessage', $params);
}

function editMessage($chatId, $messageId, string $text, array $keyboard = null)
{
    $params = [
        'chat_id' => $chatId,
        'message_id' => $messageId,
        'text' => $text,
        'parse_mode' => 'HTML',
    ];
    if ($keyboard !== null) {
        $params['reply_markup'] = json_encode(['inline_keyboard' => $keyboard], JSON_UNESCAPED_UNICODE);
    }
    return tg_api('editMessageText', $params);
}

// نسخة "ذكية" من تعديل الرسالة: إذا فشل التعديل لأي سبب (رسالة قديمة، لا تغيير،
// أو أي خطأ آخر) يرسل رسالة جديدة بدلاً منها بدلاً من ما يختفي الرد بصمت.
// استخدم هذه بدل editMessage مباشرة في كل مكان بالبوت.
function reply($chatId, $messageId, string $text, array $keyboard = null)
{
    $res = editMessage($chatId, $messageId, $text, $keyboard);
    if (empty($res['ok'])) {
        sendMessage($chatId, $text, $keyboard);
    }
}

function answerCallback($callbackId, string $text = '')
{
    return tg_api('answerCallbackQuery', [
        'callback_query_id' => $callbackId,
        'text' => $text,
    ]);
}

// تحميل ملف مرسل من تيليغرام (صورة أو تطبيق) وحفظه محلياً عبر cURL
// (أكثر موثوقية من file_get_contents لأن بعض الاستضافات تمنع allow_url_fopen)
function downloadTelegramFile(string $fileId, string $destDir, string $desiredName): ?string
{
    $fileInfo = tg_api('getFile', ['file_id' => $fileId]);
    if (empty($fileInfo['ok'])) {
        return null;
    }
    $filePath = $fileInfo['result']['file_path'];
    $ext = pathinfo($filePath, PATHINFO_EXTENSION);
    $localName = $desiredName . ($ext ? ('.' . $ext) : '');
    $fileUrl = 'https://api.telegram.org/file/bot' . BOT_TOKEN . '/' . $filePath;

    $ch = curl_init($fileUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    $content = curl_exec($ch);
    $errNo = curl_errno($ch);
    $err = curl_error($ch);
    curl_close($ch);

    if ($errNo || $content === false) {
        error_log("[downloadTelegramFile] CURL error #$errNo: $err");
        return null;
    }
    if (!is_dir($destDir)) {
        @mkdir($destDir, 0775, true);
    }
    if (!is_writable($destDir)) {
        error_log("[downloadTelegramFile] المجلد غير قابل للكتابة: $destDir");
        return null;
    }
    file_put_contents($destDir . $localName, $content);
    @chmod($destDir . $localName, 0644); // نضمن صلاحية قراءة للجميع بغض النظر عن إعدادات السيرفر
    return $localName;
}

// تحميل ملف من رابط مباشر خارج تيليغرام (للملفات الأكبر من 20 ميجابايت
// التي يرفضها تيليغرام تحميلها عبر getFile)
function downloadFromUrl(string $url, string $destDir, string $desiredName): ?string
{
    @set_time_limit(600); // ملفات كبيرة قد تحتاج وقتاً أطول من الحد الافتراضي (30 ثانية)
    $ext = pathinfo(parse_url($url, PHP_URL_PATH) ?: '', PATHINFO_EXTENSION);
    $localName = $desiredName . ($ext ? ('.' . $ext) : '.apk');

    if (!is_dir($destDir)) {
        @mkdir($destDir, 0775, true);
    }
    if (!is_writable($destDir)) {
        error_log("[downloadFromUrl] المجلد غير قابل للكتابة: $destDir");
        return null;
    }

    $fp = fopen($destDir . $localName, 'w');
    if (!$fp) {
        error_log("[downloadFromUrl] تعذر إنشاء الملف: $destDir$localName");
        return null;
    }

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
    curl_setopt($ch, CURLOPT_TIMEOUT, 600); // يسمح بملفات كبيرة عبر اتصال بطيء
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0');
    $success = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $errNo = curl_errno($ch);
    $err = curl_error($ch);
    curl_close($ch);
    fclose($fp);
    @chmod($destDir . $localName, 0644); // نضمن صلاحية قراءة للجميع بغض النظر عن إعدادات السيرفر

    if (!$success || $errNo || $httpCode >= 400) {
        error_log("[downloadFromUrl] فشل التحميل من $url - HTTP:$httpCode CURL#$errNo: $err");
        @unlink($destDir . $localName);
        return null;
    }
    if (filesize($destDir . $localName) < 1024) {
        // ملف صغير جداً غالباً معناه إنه صفحة خطأ HTML مو الملف الفعلي
        error_log("[downloadFromUrl] الملف المحمّل صغير جداً وقد يكون غير صحيح: $url");
    }
    return $localName;
}

// ============================================================
//                     دوال الإعدادات (settings)
// ============================================================

function getSetting(string $key, string $default = ''): string
{
    $stmt = db()->prepare("SELECT value FROM settings WHERE key = ?");
    $stmt->execute([$key]);
    $res = $stmt->fetch(PDO::FETCH_ASSOC);
    return $res['value'] ?? $default;
}

function setSetting(string $key, string $value): void
{
    $stmt = db()->prepare("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)");
    $stmt->execute([$key, $value]);
}

// ============================================================
//                 دوال حالة المحادثة (bot_states)
// ============================================================
// تستخدم لتتبع خطوات الإدخال المتعددة (اسم الصفحة ثم المحتوى...الخ)

function getState($chatId): array
{
    $stmt = db()->prepare("SELECT state, data FROM bot_states WHERE chat_id = ?");
    $stmt->execute([$chatId]);
    $res = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$res) {
        return ['state' => 'idle', 'data' => []];
    }
    return ['state' => $res['state'], 'data' => json_decode($res['data'] ?? '{}', true) ?: []];
}

function setState($chatId, string $state, array $data = []): void
{
    $json = json_encode($data, JSON_UNESCAPED_UNICODE);
    $stmt = db()->prepare("INSERT OR REPLACE INTO bot_states (chat_id, state, data) VALUES (?, ?, ?)");
    $stmt->execute([$chatId, $state, $json]);
}

function clearState($chatId): void
{
    setState($chatId, 'idle', []);
}

// ============================================================
//                     دوال الصفحات والكليشات
// ============================================================

function slugify(string $text): string
{
    $slug = trim(preg_replace('/[^a-zA-Z0-9\x{0600}-\x{06FF}]+/u', '-', $text), '-');
    $slug = strtolower($slug);
    return $slug !== '' ? $slug . '-' . substr(md5(uniqid()), 0, 5) : uniqid('page-');
}

function getAllPages(): array
{
    $stmt = db()->query("SELECT * FROM pages ORDER BY sort_order ASC, id ASC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getPageBySlug(string $slug): ?array
{
    $stmt = db()->prepare("SELECT * FROM pages WHERE slug = ?");
    $stmt->execute([$slug]);
    $r = $stmt->fetch(PDO::FETCH_ASSOC);
    return $r ?: null;
}

function getHomePage(): ?array
{
    $stmt = db()->query("SELECT * FROM pages WHERE type = 'home' ORDER BY id ASC LIMIT 1");
    $r = $stmt->fetch(PDO::FETCH_ASSOC);
    return $r ?: null;
}

function getPageById(int $id): ?array
{
    $stmt = db()->prepare("SELECT * FROM pages WHERE id = ?");
    $stmt->execute([$id]);
    $r = $stmt->fetch(PDO::FETCH_ASSOC);
    return $r ?: null;
}

function updatePageContent(int $id, string $content): void
{
    $stmt = db()->prepare("UPDATE pages SET content = ? WHERE id = ?");
    $stmt->execute([$content, $id]);
}

function updatePageTitle(int $id, string $title): void
{
    $stmt = db()->prepare("UPDATE pages SET title = ? WHERE id = ?");
    $stmt->execute([$title, $id]);
}

function getClichesByPage(int $pageId): array
{
    $stmt = db()->prepare("SELECT * FROM cliches WHERE page_id = ? ORDER BY sort_order ASC, id ASC");
    $stmt->execute([$pageId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getClicheById(int $id): ?array
{
    $stmt = db()->prepare("SELECT * FROM cliches WHERE id = ?");
    $stmt->execute([$id]);
    $r = $stmt->fetch(PDO::FETCH_ASSOC);
    return $r ?: null;
}

function e(string $text): string
{
    return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}

// يحوّل نص المحتوى الخام إلى HTML منظم:
// - يدمج الأسطر الفارغة المتكررة بدل ما تصير فراغات ضخمة بالصفحة
// - يحوّل أي [نص الزر](رابط) إلى زر برتقالي حقيقي قابل للضغط
// - يقسّم المحتوى لفقرات حقيقية بدل سطر تحت سطر بمسافة كبيرة
function renderContent(string $text): string
{
    $text = trim($text);
    if ($text === '') {
        return '';
    }
    // أي 3 أسطر فارغة أو أكثر تتحول لفاصل فقرة واحد فقط
    $text = preg_replace('/\n{3,}/', "\n\n", $text);

    $escaped = e($text);

    // [نص الزر](https://رابط) => زر حقيقي
    $escaped = preg_replace_callback('/\[([^\[\]]+)\]\(([^()\s]+)\)/', function ($m) {
        return '<a class="btn-cta" href="' . $m[2] . '">' . $m[1] . '</a>';
    }, $escaped);

    $paragraphs = preg_split('/\n\s*\n/', $escaped);
    $html = '';
    foreach ($paragraphs as $p) {
        $p = trim($p);
        if ($p === '') {
            continue;
        }
        $html .= '<p>' . nl2br($p) . '</p>';
    }
    return $html;
}
