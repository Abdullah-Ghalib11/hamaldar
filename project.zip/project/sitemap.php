<?php
// خريطة موقع تتولد تلقائياً من قاعدة البيانات - أي صفحة تضيفها عبر بوت
// التيليغرام تنضاف هنا تلقائياً بدون أي تعديل يدوي.

error_reporting(0); // لا نريد أي تحذيرات PHP تخرب صيغة XML
require_once __DIR__ . '/functions.php';

header('Content-Type: application/xml; charset=utf-8');

$pages = getAllPages();

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

// الصفحة الرئيسية دائماً بأعلى أولوية
echo "    <url>\n";
echo "        <loc>" . e(SITE_URL) . "/</loc>\n";
echo "        <changefreq>weekly</changefreq>\n";
echo "        <priority>1.0</priority>\n";
echo "    </url>\n";

foreach ($pages as $p) {
    if ($p['type'] === 'home') {
        continue; // انعرضت فوق كرابط الجذر
    }
    echo "    <url>\n";
    echo "        <loc>" . e(SITE_URL) . "/index.php?p=" . e($p['slug']) . "</loc>\n";
    echo "        <changefreq>weekly</changefreq>\n";
    echo "        <priority>0.8</priority>\n";
    echo "    </url>\n";
}

echo '</urlset>';
