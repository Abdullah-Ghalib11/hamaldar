<?php
require_once __DIR__ . '/functions.php';

$slug = isset($_GET['p']) ? trim($_GET['p']) : '';

if ($slug === '') {
    $page = getHomePage();
} else {
    $page = getPageBySlug($slug);
}

$siteName = getSetting('site_name', 'موقعي');
$siteLogo = getSetting('site_logo', '');
$keywords = getSetting('keywords', '');
$signature = getSetting('developer_signature', '');
$allPages = getAllPages();

$pageTitle = $page ? $page['title'] : 'الصفحة الرئيسية';
$metaDescription = $page ? mb_substr(strip_tags($page['content'] ?? ''), 0, 155) : $siteName;

// رابط الشعار مع إصدار تلقائي (?v=تاريخ التعديل) حتى ما يعلق بذاكرة كاش قديمة
// أي مرة ترفع شعار جديد بنفس الاسم، الرابط يتغير تلقائياً ويجبر كل المتصفحات/Cloudflare يجيبوا النسخة الجديدة
$logoUrl = '';
if ($siteLogo) {
    $logoVersion = @filemtime(UPLOAD_SITE_DIR . $siteLogo) ?: time();
    $logoUrl = UPLOAD_SITE_URL . $siteLogo . '?v=' . $logoVersion;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> - <?= e($siteName) ?></title>
<meta name="description" content="<?= e($metaDescription) ?>">
<meta name="keywords" content="<?= e($keywords) ?>">
<meta name="google-site-verification" content="8qdl9wZ87D8J2SAq8Y-KZ7AuB8xIyZcsJnljIOsyUfg" />
<meta property="og:title" content="<?= e($pageTitle) ?> - <?= e($siteName) ?>">
<meta property="og:description" content="<?= e($metaDescription) ?>">
<?php if ($siteLogo): ?>
<meta property="og:image" content="<?= e($logoUrl) ?>">
<link rel="icon" href="<?= e($logoUrl) ?>">
<?php endif; ?>
<?php
$canonicalUrl = SITE_URL . '/' . ($slug !== '' ? 'index.php?p=' . rawurlencode($slug) : '');
?>
<link rel="canonical" href="<?= e($canonicalUrl) ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= e(ASSETS_URL) ?>style.css">
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": <?= json_encode($siteName, JSON_UNESCAPED_UNICODE) ?>,
    "url": <?= json_encode(SITE_URL . '/', JSON_UNESCAPED_UNICODE) ?>
}
</script>
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": <?= json_encode($pageTitle, JSON_UNESCAPED_UNICODE) ?>,
    "description": <?= json_encode($metaDescription, JSON_UNESCAPED_UNICODE) ?>,
    "url": <?= json_encode($canonicalUrl, JSON_UNESCAPED_UNICODE) ?>,
    "inLanguage": "ar",
    "isPartOf": {
        "@type": "WebSite",
        "name": <?= json_encode($siteName, JSON_UNESCAPED_UNICODE) ?>,
        "url": <?= json_encode(SITE_URL . '/', JSON_UNESCAPED_UNICODE) ?>
    }
}
</script>
</head>
<body>

<header class="site-header">
    <div class="header-inner">
    <div class="header-top">
        <div class="site-brand">
            <?php if ($siteLogo): ?>
                <img src="<?= e($logoUrl) ?>" alt="<?= e($siteName) ?>">
            <?php endif; ?>
            <span><?= e($siteName) ?></span>
        </div>
    </div>
    <nav class="site-nav">
        <a href="<?= e(SITE_URL) ?>/index.php">الرئيسية</a>
        <?php foreach ($allPages as $p): if ($p['type'] === 'home') continue; ?>
            <a href="<?= e(SITE_URL) ?>/index.php?p=<?= e($p['slug']) ?>"><?= e($p['title']) ?></a>
        <?php endforeach; ?>
    </nav>
    </div>
</header>

<main>
<?php if (!$page): ?>
    <div class="empty-state">لا يوجد محتوى بعد. أضف صفحة عبر بوت التحكم بالتيليغرام.</div>
<?php else: ?>
    <h1 class="page-title"><?= e($page['title']) ?></h1>

    <?php if ($page['type'] === 'app'): ?>
        <div class="app-download-box">
            <span class="app-type-badge"><?= e($page['app_type'] ?? '') ?></span>
            <div class="page-content"><?= renderContent($page['content'] ?? '') ?></div>
            <?php if (!empty($page['app_file'])): ?>
                <a class="btn-download" href="<?= e(UPLOAD_APPS_URL . $page['app_file']) ?>" download>
                    تحميل التطبيق الآن
                </a>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="page-content"><?= renderContent($page['content'] ?? '') ?></div>
    <?php endif; ?>

    <?php $cliches = getClichesByPage((int)$page['id']); ?>
    <?php if ($cliches): ?>
        <div class="cliches-grid">
            <?php foreach ($cliches as $c): ?>
                <div class="cliche-card">
                    <?php if (!empty($c['image'])): ?>
                        <img src="<?= e(UPLOAD_SITE_URL . $c['image']) ?>" alt="<?= e($c['title']) ?>">
                    <?php endif; ?>
                    <h3><?= e($c['title']) ?></h3>
                    <p><?= nl2br(e($c['description'] ?? '')) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
<?php endif; ?>
</main>

<footer class="site-footer">
    <?= e($signature) ?>
</footer>

</body>
</html>
